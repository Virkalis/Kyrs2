package ru.coursework.monitor;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import ru.coursework.monitor.api.Requests.ActivityInput;
import ru.coursework.monitor.repository.*;
import ru.coursework.monitor.service.*;

@SpringBootTest(
    properties = {
      "spring.datasource.url=jdbc:h2:mem:concurrent;DB_CLOSE_DELAY=-1",
      "spring.jpa.hibernate.ddl-auto=create-drop",
      "app.demo-data=true"
    })
class ConcurrentActivityTest {
  @Autowired MonitorService service;
  @Autowired PatientRepository patients;
  @Autowired ActivityRepository activities;

  @Test
  void concurrentSessionsCannotExceedOneDay() throws Exception {
    Long id =
        patients.findAll().stream()
            .filter(p -> p.code.equals("PM-001"))
            .findFirst()
            .orElseThrow()
            .id;
    LocalDate day = LocalDate.now().minusDays(60);
    CyclicBarrier barrier = new CyclicBarrier(2);
    Callable<Integer> action =
        () -> {
          SecurityContextHolder.getContext()
              .setAuthentication(new UsernamePasswordAuthenticationToken("doctor", "", List.of()));
          try {
            barrier.await(5, TimeUnit.SECONDS);
            service.activity(id, new ActivityInput(day, "WALK", 800, 3000, 2));
            return 201;
          } catch (BusinessException e) {
            return e.status;
          } finally {
            SecurityContextHolder.clearContext();
          }
        };
    try (ExecutorService pool = Executors.newFixedThreadPool(2)) {
      var first = pool.submit(action);
      var second = pool.submit(action);
      List<Integer> outcomes =
          List.of(first.get(15, TimeUnit.SECONDS), second.get(15, TimeUnit.SECONDS));
      assertTrue(outcomes.contains(201));
      assertTrue(outcomes.contains(409));
    }
    var saved = activities.findByPatientIdAndDayBetweenOrderByDayAsc(id, day, day);
    assertEquals(1, saved.size());
    assertEquals(800, saved.getFirst().minutes);
  }
}
