package ru.coursework.monitor;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.*;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.*;
import ru.coursework.monitor.domain.*;
import ru.coursework.monitor.repository.*;

@SpringBootTest(
    properties = {
      "spring.datasource.url=jdbc:h2:mem:integration;DB_CLOSE_DELAY=-1",
      "spring.jpa.hibernate.ddl-auto=create-drop",
      "app.demo-data=true"
    })
@AutoConfigureMockMvc
class MonitorIntegrationTest {
  @Autowired MockMvc mvc;
  @Autowired ObjectMapper json;
  @Autowired PatientRepository patients;
  @Autowired AlertRepository alerts;
  @Autowired MeasurementRepository measurements;
  @Autowired ActivityRepository activities;
  @Autowired MonitoringRuleRepository rules;
  @Autowired AuditEventRepository audit;
  Long id, other;

  @BeforeEach
  void setUp() {
    id =
        patients.findAll().stream()
            .filter(p -> p.code.equals("PM-001"))
            .findFirst()
            .orElseThrow()
            .id;
    other =
        patients.findAll().stream()
            .filter(p -> p.code.equals("PM-004"))
            .findFirst()
            .orElseThrow()
            .id;
    Patient p = patients.findById(id).orElseThrow();
    p.active = true;
    p.stepGoal = 6000;
    patients.save(p);
  }

  String range() {
    return "?from=" + LocalDate.now().minusDays(30) + "&to=" + LocalDate.now();
  }

  String body(Object v) throws Exception {
    return json.writeValueAsString(v);
  }

  Map<String, Object> reading(double value) {
    return Map.of(
        "metric",
        "PULSE",
        "value",
        value,
        "occurredAt",
        Instant.now().minusSeconds(60).toString(),
        "note",
        "Контрольный пример");
  }

  ResultActions send(String path, Object value, String user) throws Exception {
    return mvc.perform(
        post(path)
            .with(user(user))
            .with(csrf())
            .contentType("application/json")
            .content(body(value)));
  }

  ResultActions update(String path, Object value, String user) throws Exception {
    return mvc.perform(
        put(path)
            .with(user(user))
            .with(csrf())
            .contentType("application/json")
            .content(body(value)));
  }

  Long levelPatient() {
    Patient p = new Patient();
    p.fullName = "Проверка уровней";
    p.code = "LEVEL-" + UUID.randomUUID();
    p.birthDate = LocalDate.of(1990, 1, 1);
    p.doctor = patients.findById(id).orElseThrow().doctor;
    return patients.save(p).id;
  }

  void levelRule(Long patientId, String metric) throws Exception {
    update("/api/patients/" + patientId + "/rule",
        Map.of("metric", metric, "lowerBound", 55, "upperBound", 100,
            "criticalLowerBound", 40, "criticalUpperBound", 130), "doctor")
        .andExpect(status().isOk());
  }

  void levelReading(Long patientId, String metric, double value, Instant time) throws Exception {
    send("/api/patients/" + patientId + "/measurements",
        Map.of("metric", metric, "value", value, "occurredAt", time.toString()), "doctor")
        .andExpect(status().isCreated());
  }

  @Test
  void pulseIsAssessedWithoutIndividualRule() throws Exception {
    var created = send("/api/patients",
        Map.of("fullName", "Проверка пульса", "code", "PULSE-DEFAULT",
            "birthDate", "1990-01-01", "doctorId", patients.findById(id).orElseThrow().doctor.id,
            "stepGoal", 6000), "doctor")
        .andExpect(status().isCreated())
        .andReturn();
    long patientId = json.readTree(created.getResponse().getContentAsString()).get("id").asLong();
    assertTrue(rules.findByPatientId(patientId).isEmpty());
    String path = "/api/patients/" + patientId + range();
    mvc.perform(get(path).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("UNKNOWN"))
        .andExpect(jsonPath("$.rules[0].metric").value("PULSE"));

    Instant time = Instant.now().minusSeconds(600);
    Measurement existing = new Measurement();
    existing.patient = patients.findById(patientId).orElseThrow();
    existing.metric = Metric.PULSE;
    existing.value = 200;
    existing.occurredAt = time;
    existing.registeredAt = time;
    existing.author = "doctor";
    measurements.save(existing);
    mvc.perform(get(path).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("RED"))
        .andExpect(jsonPath("$.measurements[0].level").value("RED"))
        .andExpect(jsonPath("$.alerts.length()").value(0));

    levelReading(patientId, "PULSE", 200, time.plusSeconds(1));
    mvc.perform(get(path).with(user("doctor")))
        .andExpect(jsonPath("$.alerts.length()").value(1))
        .andExpect(jsonPath("$.alerts[0].level").value("RED"))
        .andExpect(jsonPath("$.alerts[0].value").value(200));
  }

  @Test
  void levelsEscalateAndRecoverWhileHistoricalAlertsKeepTheirLevel() throws Exception {
    Long patientId = levelPatient();
    levelRule(patientId, "PULSE");
    Instant time = Instant.now().minusSeconds(600);
    levelReading(patientId, "PULSE", 75, time);
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("GREEN"))
        .andExpect(jsonPath("$.alerts.length()").value(0));
    levelReading(patientId, "PULSE", 112, time.plusSeconds(1));
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("YELLOW"))
        .andExpect(jsonPath("$.alerts[0].level").value("YELLOW"));
    levelReading(patientId, "PULSE", 130, time.plusSeconds(2));
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("RED"))
        .andExpect(jsonPath("$.measurements[2].level").value("RED"))
        .andExpect(jsonPath("$.alerts[0].level").value("RED"));
    levelReading(patientId, "PULSE", 80, time.plusSeconds(3));
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("GREEN"))
        .andExpect(jsonPath("$.alerts.length()").value(2))
        .andExpect(jsonPath("$.alerts[0].level").value("RED"));
    // Меняются текущие оценки, но снимок события сохраняется.
    update("/api/patients/" + patientId + "/rule",
        Map.of("metric", "PULSE", "lowerBound", 55, "upperBound", 140,
            "criticalLowerBound", 40, "criticalUpperBound", 180), "doctor")
        .andExpect(status().isOk());
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.measurements[2].level").value("GREEN"))
        .andExpect(jsonPath("$.alerts[0].criticalUpperBound").value(130))
        .andExpect(jsonPath("$.alerts[0].level").value("RED"));
  }

  @Test
  void summaryUsesWorstLatestMetricRegardlessOfPeriodOrRegistrationOrder() throws Exception {
    Long patientId = levelPatient();
    levelRule(patientId, "PULSE");
    levelRule(patientId, "SYSTOLIC");
    Instant time = Instant.now().minusSeconds(600);
    levelReading(patientId, "PULSE", 130, time);
    levelReading(patientId, "SYSTOLIC", 75, time.plusSeconds(1));
    levelReading(patientId, "PULSE", 75, time.minusSeconds(1));
    // При одинаковом времени выбирается последняя зарегистрированная запись.
    levelReading(patientId, "SYSTOLIC", 112, time.plusSeconds(1));
    String oldPeriod = "?from=2020-01-01&to=2020-01-01";
    mvc.perform(get("/api/patients/" + patientId + oldPeriod).with(user("doctor")))
        .andExpect(jsonPath("$.measurements.length()").value(0))
        .andExpect(jsonPath("$.patient.health.level").value("RED"))
        .andExpect(jsonPath("$.patient.health.measurements.length()").value(2))
        .andExpect(jsonPath("$.patient.health.measurements[?(@.metric == 'SYSTOLIC')].level")
            .value(org.hamcrest.Matchers.contains("YELLOW")));
    Patient p = patients.findById(patientId).orElseThrow();
    mvc.perform(get("/api/patients?search=" + p.code).with(user("doctor")))
        .andExpect(jsonPath("$[0].health.level").value("RED"));
  }

  @Test
  void missingMeasurementsOrRulesAreNotShownAsNormal() throws Exception {
    Long patientId = levelPatient();
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("UNKNOWN"));
    levelRule(patientId, "PULSE");
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("UNKNOWN"))
        .andExpect(jsonPath("$.patient.health.unassessedCount").value(1));
    Measurement legacy = new Measurement();
    legacy.patient = patients.findById(patientId).orElseThrow();
    legacy.metric = Metric.WEIGHT;
    legacy.value = 70;
    legacy.occurredAt = Instant.now().minusSeconds(60);
    legacy.registeredAt = legacy.occurredAt;
    legacy.author = "doctor";
    measurements.save(legacy);
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("UNKNOWN"))
        .andExpect(jsonPath("$.patient.health.unassessedCount").value(2))
        .andExpect(jsonPath("$.measurements[0].level").value("UNKNOWN"))
        .andExpect(jsonPath("$.alerts.length()").value(0));
  }

  @Test
  void legacyRulesAndAlertsUseFallbackCriticalBounds() throws Exception {
    Long patientId = levelPatient();
    update("/api/patients/" + patientId + "/rule",
        Map.of("metric", "PULSE", "lowerBound", 55, "upperBound", 100), "doctor")
        .andExpect(status().isOk());
    levelReading(patientId, "PULSE", 130, Instant.now().minusSeconds(60));
    Alert a = alerts.findByMeasurementPatientIdOrderByIdDesc(patientId).getFirst();
    a.criticalLowerBound = null;
    a.criticalUpperBound = null;
    alerts.save(a);
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("RED"))
        .andExpect(jsonPath("$.rules[0].criticalLowerBound").value(32.5))
        .andExpect(jsonPath("$.rules[0].criticalUpperBound").value(122.5))
        .andExpect(jsonPath("$.alerts[0].level").value("RED"));
  }

  @Test
  void rejectsCriticalBoundsInsideNormalRange() throws Exception {
    Long patientId = levelPatient();
    for (var bounds : List.of(new double[]{55, 130}, new double[]{40, 100}, new double[]{80, 90})) {
      update("/api/patients/" + patientId + "/rule",
          Map.of("metric", "PULSE", "lowerBound", 55, "upperBound", 100,
              "criticalLowerBound", bounds[0], "criticalUpperBound", bounds[1]), "doctor")
          .andExpect(status().isBadRequest());
    }
    assertTrue(rules.findByPatientId(patientId).isEmpty());
  }

  @Test
  void anonymousDenied() throws Exception {
    mvc.perform(get("/api/patients")).andExpect(status().isUnauthorized());
  }

  @Test
  void csrfIsRequired() throws Exception {
    mvc.perform(
            post("/api/patients/" + id + "/measurements")
                .with(user("doctor"))
                .contentType("application/json")
                .content(body(reading(75))))
        .andExpect(status().isForbidden());
  }

  @Test
  void actualLoginAndLogout() throws Exception {
    var result =
        mvc.perform(
                post("/api/session/login")
                    .with(csrf())
                    .param("username", "doctor")
                    .param("password", "Doctor2026!"))
            .andExpect(status().isOk())
            .andReturn();
    var session =
        (org.springframework.mock.web.MockHttpSession) result.getRequest().getSession(false);
    assertNotNull(session);
    mvc.perform(get("/api/session/me").session(session))
        .andExpect(jsonPath("$.role").value("DOCTOR"));
    mvc.perform(post("/api/session/logout").session(session).with(csrf()))
        .andExpect(status().isNoContent());
  }

  @Test
  void wrongPassword() throws Exception {
    mvc.perform(
            post("/api/session/login")
                .with(csrf())
                .param("username", "doctor")
                .param("password", "incorrect"))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void doctorCannotReadOtherPatient() throws Exception {
    mvc.perform(get("/api/patients/" + other + range()).with(user("doctor")))
        .andExpect(status().isForbidden());
  }

  @Test
  void patientSeesOnlyOwnCard() throws Exception {
    mvc.perform(get("/api/patients").with(user("patient")))
        .andExpect(jsonPath("$.length()").value(1))
        .andExpect(jsonPath("$[0].code").value("PM-001"));
  }

  @Test
  void patientCannotWriteAnotherCard() throws Exception {
    send("/api/patients/" + other + "/measurements", reading(80), "patient")
        .andExpect(status().isForbidden());
  }

  @Test
  void patientCannotSetRule() throws Exception {
    update(
            "/api/patients/" + id + "/rule",
            Map.of("metric", "PULSE", "lowerBound", 50, "upperBound", 100),
            "patient")
        .andExpect(status().isForbidden());
  }

  @Test
  void missingRequiredValue() throws Exception {
    send("/api/patients/" + id + "/measurements", Map.of("metric", "PULSE"), "doctor")
        .andExpect(status().isBadRequest());
  }

  @Test
  void rejectsFutureMeasurement() throws Exception {
    var v = new HashMap<>(reading(80));
    v.put("occurredAt", Instant.now().plusSeconds(3600).toString());
    send("/api/patients/" + id + "/measurements", v, "doctor").andExpect(status().isBadRequest());
  }

  @Test
  void rejectsTechnicalOutOfRange() throws Exception {
    send("/api/patients/" + id + "/measurements", reading(999), "doctor")
        .andExpect(status().isBadRequest());
  }

  @Test
  void thresholdSnapshotAndFullReviewLifecycle() throws Exception {
    update(
            "/api/patients/" + id + "/rule",
            Map.of("metric", "PULSE", "lowerBound", 55, "upperBound", 100),
            "doctor")
        .andExpect(status().isOk());
    long mid =
        json.readTree(
                send("/api/patients/" + id + "/measurements", reading(112), "patient")
                    .andExpect(status().isCreated())
                    .andReturn()
                    .getResponse()
                    .getContentAsString())
            .get("id")
            .asLong();
    Alert a =
        alerts.findAll().stream().filter(x -> x.measurement.id == mid).findFirst().orElseThrow();
    assertEquals(100, a.upperBound);
    update(
            "/api/patients/" + id + "/rule",
            Map.of("metric", "PULSE", "lowerBound", 55, "upperBound", 120),
            "doctor")
        .andExpect(status().isOk());
    assertEquals(100, alerts.findById(a.id).orElseThrow().upperBound);
    String path = "/api/patients/" + id + "/alerts/" + a.id;
    update(
            path,
            Map.of("status", "RESOLVED", "comment", "Нельзя пропустить этап", "version", a.version),
            "doctor")
        .andExpect(status().isConflict());
    update(
            path,
            Map.of("status", "ACKNOWLEDGED", "comment", "Наблюдение принято", "version", a.version),
            "doctor")
        .andExpect(status().isOk());
    a = alerts.findById(a.id).orElseThrow();
    update(
            path,
            Map.of(
                "status",
                "RESOLVED",
                "comment",
                "Повторная запись проверена",
                "version",
                a.version),
            "doctor")
        .andExpect(status().isOk());
    assertEquals("RESOLVED", alerts.findById(a.id).orElseThrow().status);
  }

  @Test
  void boundaryDoesNotCreateAlert() throws Exception {
    update(
        "/api/patients/" + id + "/rule",
        Map.of("metric", "PULSE", "lowerBound", 55, "upperBound", 100),
        "doctor");
    long before = alerts.count();
    send("/api/patients/" + id + "/measurements", reading(100), "doctor")
        .andExpect(status().isCreated());
    assertEquals(before, alerts.count());
  }

  @Test
  void adultPresetsApplyToAllVitalSigns() throws Exception {
    Long patientId = levelPatient();
    Instant time = Instant.now().minusSeconds(600);
    for (String metric : List.of("PULSE", "SYSTOLIC", "DIASTOLIC", "TEMPERATURE", "SPO2")) {
      double[] examples = switch (metric) {
        case "PULSE" -> new double[]{75, 112, 200};
        case "SYSTOLIC" -> new double[]{110, 135, 190};
        case "DIASTOLIC" -> new double[]{70, 95, 130};
        case "TEMPERATURE" -> new double[]{36.6, 38.5, 40};
        default -> new double[]{98, 94, 90};
      };
      for (int i = 0; i < examples.length; i++)
        levelReading(patientId, metric, examples[i], time.plusSeconds(i));
    }
    mvc.perform(get("/api/patients/" + patientId + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.level").value("RED"))
        .andExpect(jsonPath("$.measurements[?(@.level == 'GREEN')]").value(org.hamcrest.Matchers.hasSize(5)))
        .andExpect(jsonPath("$.measurements[?(@.level == 'YELLOW')]").value(org.hamcrest.Matchers.hasSize(5)))
        .andExpect(jsonPath("$.alerts[?(@.level == 'RED')]").value(org.hamcrest.Matchers.hasSize(5)))
        .andExpect(jsonPath("$.alerts.length()").value(10));
  }

  @Test
  void weightRequiresHeightAndUsesBmiForLevelsAndAlerts() throws Exception {
    Long patientId = levelPatient();
    String path = "/api/patients/" + patientId;
    Instant time = Instant.now().minusSeconds(600);
    var input = new HashMap<String, Object>(Map.of(
        "metric", "WEIGHT", "value", 100, "occurredAt", time.toString()));
    send(path + "/measurements", input, "doctor").andExpect(status().isBadRequest());
    input.put("heightCm", 0);
    send(path + "/measurements", input, "doctor").andExpect(status().isBadRequest());
    input.put("heightCm", 200);
    send(path + "/measurements", input, "doctor").andExpect(status().isCreated());
    input.put("heightCm", 150);
    input.put("occurredAt", time.plusSeconds(1).toString());
    send(path + "/measurements", input, "doctor").andExpect(status().isCreated());
    input.put("value", 88);
    input.put("heightCm", 200);
    input.put("occurredAt", time.plusSeconds(2).toString());
    send(path + "/measurements", input, "doctor").andExpect(status().isCreated());

    mvc.perform(get(path + range()).with(user("doctor")))
        .andExpect(jsonPath("$.measurements.length()").value(3))
        .andExpect(jsonPath("$.measurements[0].bmi").value(25))
        .andExpect(jsonPath("$.measurements[0].level").value("YELLOW"))
        .andExpect(jsonPath("$.measurements[1].bmi").value(44.44))
        .andExpect(jsonPath("$.measurements[1].level").value("RED"))
        .andExpect(jsonPath("$.patient.health.measurements[0].heightCm").value(200))
        .andExpect(jsonPath("$.patient.health.measurements[0].bmi").value(22))
        .andExpect(jsonPath("$.patient.health.level").value("GREEN"))
        .andExpect(jsonPath("$.alerts.length()").value(2))
        .andExpect(jsonPath("$.alerts[0].metric").value("BMI"))
        .andExpect(jsonPath("$.alerts[0].value").value(44.44))
        .andExpect(jsonPath("$.alerts[0].level").value("RED"));

    update(path + "/rule",
        Map.of("metric", "BMI", "lowerBound", 20, "upperBound", 30,
            "criticalLowerBound", 15, "criticalUpperBound", 45), "doctor")
        .andExpect(status().isOk());
    mvc.perform(get(path + range()).with(user("doctor")))
        .andExpect(jsonPath("$.measurements[0].level").value("GREEN"))
        .andExpect(jsonPath("$.alerts[1].level").value("YELLOW"));
  }

  @Test
  void calculatesBmiForYoungPatientWithoutApplyingAdultPreset() throws Exception {
    Patient p = patients.findById(levelPatient()).orElseThrow();
    p.birthDate = LocalDate.now().minusYears(19);
    patients.save(p);
    String path = "/api/patients/" + p.id;
    send(path + "/measurements",
        Map.of("metric", "WEIGHT", "value", 100, "heightCm", 150,
            "occurredAt", Instant.now().minusSeconds(60).toString()), "doctor")
        .andExpect(status().isCreated());
    mvc.perform(get(path + range()).with(user("doctor")))
        .andExpect(jsonPath("$.patient.health.measurements[0].bmi").value(44.44))
        .andExpect(jsonPath("$.patient.health.level").value("UNKNOWN"))
        .andExpect(jsonPath("$.alerts.length()").value(0));
  }

  @Test
  void rejectsReversedRule() throws Exception {
    update(
            "/api/patients/" + id + "/rule",
            Map.of("metric", "PULSE", "lowerBound", 120, "upperBound", 60),
            "doctor")
        .andExpect(status().isBadRequest());
  }

  @Test
  void archivedCardRejectsNewData() throws Exception {
    Patient p = patients.findById(id).orElseThrow();
    update(
            "/api/patients/" + id + "/status",
            Map.of("active", false, "version", p.version),
            "doctor")
        .andExpect(status().isOk());
    long before = measurements.count();
    send("/api/patients/" + id + "/measurements", reading(75), "doctor")
        .andExpect(status().isConflict());
    assertEquals(before, measurements.count());
    mvc.perform(get("/api/patients/" + id + range()).with(user("doctor")))
        .andExpect(status().isOk());
  }

  @Test
  void staleCardRejected() throws Exception {
    Patient p = patients.findById(id).orElseThrow();
    update("/api/patients/" + id + "/goal", Map.of("steps", 7000, "version", p.version), "doctor")
        .andExpect(status().isOk());
    update("/api/patients/" + id + "/goal", Map.of("steps", 8000, "version", p.version), "doctor")
        .andExpect(status().isConflict());
  }

  @Test
  void activityTotalsAndDayLimit() throws Exception {
    LocalDate day = LocalDate.now().minusDays(20);
    Map<String, Object> a =
        Map.of(
            "day", day.toString(), "kind", "WALK", "minutes", 60, "steps", 3000, "distanceKm", 2.1);
    send("/api/patients/" + id + "/activities", a, "patient").andExpect(status().isCreated());
    send("/api/patients/" + id + "/activities", a, "patient").andExpect(status().isCreated());
    mvc.perform(get("/api/patients/" + id + "?from=" + day + "&to=" + day).with(user("doctor")))
        .andExpect(jsonPath("$.days[0].steps").value(6000))
        .andExpect(jsonPath("$.days[0].minutes").value(120))
        .andExpect(jsonPath("$.days[0].goalPercent").value(100));
    var excess = new HashMap<>(a);
    excess.put("minutes", 1440);
    send("/api/patients/" + id + "/activities", excess, "doctor").andExpect(status().isConflict());
  }

  @Test
  void unknownMetricRejected() throws Exception {
    var v = new HashMap<>(reading(80));
    v.put("metric", "UNKNOWN");
    send("/api/patients/" + id + "/measurements", v, "doctor").andExpect(status().isBadRequest());
  }

  @Test
  void reversedPeriodRejected() throws Exception {
    mvc.perform(get("/api/patients/" + id + "?from=2026-09-20&to=2026-09-01").with(user("doctor")))
        .andExpect(status().isBadRequest());
  }

  @Test
  void auditHiddenFromPatient() throws Exception {
    mvc.perform(get("/api/patients/" + id + range()).with(user("patient")))
        .andExpect(jsonPath("$.audit.length()").value(0));
  }

  @Test
  void uniqueCodeAndDoctorAssignment() throws Exception {
    long doctor = patients.findById(id).orElseThrow().doctor.id;
    Map<String, Object> input =
        Map.of(
            "fullName",
            "Тестовый Пациент",
            "code",
            "TEST-01",
            "birthDate",
            "1995-05-10",
            "doctorId",
            doctor,
            "stepGoal",
            6000);
    send("/api/patients", input, "doctor").andExpect(status().isCreated());
    send("/api/patients", input, "doctor").andExpect(status().isConflict());
    var foreign = new HashMap<>(input);
    foreign.put("code", "TEST-02");
    foreign.put("doctorId", patients.findById(other).orElseThrow().doctor.id);
    send("/api/patients", foreign, "doctor").andExpect(status().isForbidden());
  }

  @Test
  void patientCannotReview() throws Exception {
    Alert a = alerts.findByMeasurementPatientIdOrderByIdDesc(id).getFirst();
    update(
            "/api/patients/" + id + "/alerts/" + a.id,
            Map.of("status", "ACKNOWLEDGED", "comment", "test", "version", a.version),
            "patient")
        .andExpect(status().isForbidden());
  }
}
