package ru.coursework.monitor;

import static org.junit.jupiter.api.Assertions.*;

import java.time.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import ru.coursework.monitor.domain.Metric;
import ru.coursework.monitor.domain.HealthLevel;
import ru.coursework.monitor.service.*;

class MonitoringPolicyTest {
  @ParameterizedTest
  @CsvSource({"40,RED", "41,YELLOW", "54,YELLOW", "55,GREEN", "75,GREEN",
      "100,GREEN", "101,YELLOW", "129.9,YELLOW", "130,RED", "180,RED", "20,RED"})
  void threeLevelsAndInclusiveCriticalBounds(double value, HealthLevel expected) {
    assertEquals(expected, MonitoringPolicy.level(value, 55, 100, 40.0, 130.0));
  }

  @Test
  void legacyRulesHaveDeterministicCriticalBounds() {
    assertEquals(32.5, MonitoringPolicy.criticalLow(55, 100, null));
    assertEquals(122.5, MonitoringPolicy.criticalHigh(55, 100, null));
    assertEquals(HealthLevel.YELLOW, MonitoringPolicy.level(112, 55, 100, null, null));
    assertEquals(HealthLevel.RED, MonitoringPolicy.level(122.5, 55, 100, null, null));
    assertEquals(HealthLevel.RED, MonitoringPolicy.level(32.5, 55, 100, null, null));
  }

  @Test
  void criticalBoundsMustSurroundNormalRangeAndBeFinite() {
    MonitoringPolicy.criticalBounds(55, 100, null, null);
    MonitoringPolicy.criticalBounds(55, 100, 40.0, 130.0);
    assertThrows(BusinessException.class, () -> MonitoringPolicy.criticalBounds(55, 100, 55.0, 130.0));
    assertThrows(BusinessException.class, () -> MonitoringPolicy.criticalBounds(55, 100, 40.0, 100.0));
    assertThrows(BusinessException.class, () -> MonitoringPolicy.criticalBounds(55, 100, Double.NaN, null));
    assertThrows(BusinessException.class, () -> MonitoringPolicy.criticalBounds(55, 100, null, Double.POSITIVE_INFINITY));
  }

  @ParameterizedTest
  @CsvSource({"54,true", "55,false", "75,false", "100,false", "101,true"})
  void inclusiveBounds(double value, boolean expected) {
    assertEquals(expected, MonitoringPolicy.outside(value, 55, 100));
  }

  @Test
  void rejectsNonFinite() {
    assertThrows(BusinessException.class, () -> MonitoringPolicy.reading(Metric.PULSE, Double.NaN));
    assertThrows(
        BusinessException.class,
        () -> MonitoringPolicy.reading(Metric.PULSE, Double.POSITIVE_INFINITY));
  }

  @Test
  void technicalLimits() {
    MonitoringPolicy.reading(Metric.SPO2, 100);
    assertThrows(BusinessException.class, () -> MonitoringPolicy.reading(Metric.SPO2, 101));
  }

  @Test
  void periodBounds() {
    LocalDate d = LocalDate.of(2026, 1, 1);
    MonitoringPolicy.period(d, d.plusDays(365));
    assertThrows(BusinessException.class, () -> MonitoringPolicy.period(d, d.plusDays(366)));
    assertThrows(BusinessException.class, () -> MonitoringPolicy.period(d, d.minusDays(1)));
  }

  @Test
  void futureRejected() {
    Instant now = Instant.parse("2026-09-27T10:00:00Z");
    MonitoringPolicy.time(now, now);
    assertThrows(BusinessException.class, () -> MonitoringPolicy.time(now.plusSeconds(1), now));
  }

  @Test
  void lifecycle() {
    MonitoringPolicy.transition("NEW", "ACKNOWLEDGED");
    MonitoringPolicy.transition("ACKNOWLEDGED", "RESOLVED");
    assertThrows(BusinessException.class, () -> MonitoringPolicy.transition("NEW", "RESOLVED"));
    assertThrows(
        BusinessException.class, () -> MonitoringPolicy.transition("RESOLVED", "ACKNOWLEDGED"));
  }

  @Test
  void moscowDayBoundary() {
    assertEquals(
        Instant.parse("2026-09-26T21:00:00Z"),
        LocalDate.of(2026, 9, 27).atStartOfDay(MonitoringPolicy.ZONE).toInstant());
  }
}
