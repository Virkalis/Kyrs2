const $ = (s) => document.querySelector(s),
  esc = (v) =>
    String(v ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
let user,
  metrics = [],
  people = [],
  selected = null,
  data = null,
  tab = "observations",
  modalAction;
const labels = {
  GREEN: "В норме",
  YELLOW: "Отклонение",
  RED: "Сильное отклонение",
  UNKNOWN: "Нет оценки",
  NEW: "Новое",
  ACKNOWLEDGED: "В работе",
  RESOLVED: "Завершено",
  WALK: "Ходьба",
  RUN: "Бег",
  CYCLE: "Велосипед",
  OTHER: "Другое",
};
const fmt = (v) =>
    Number(v).toLocaleString("ru-RU", { maximumFractionDigits: 1 }),
  date = (v) =>
    new Date(v).toLocaleString("ru-RU", {
      timeZone: "Europe/Moscow",
      dateStyle: "short",
      timeStyle: "short",
    });
const localDay = () =>
  new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Moscow" }).format(
    new Date(),
  );
function toast(message) {
  $("#toast").textContent = message;
  $("#toast").hidden = false;
  setTimeout(() => ($("#toast").hidden = true), 4500);
}
async function request(url, method = "GET", body) {
  const headers = {};
  if (method !== "GET") {
    const r = await fetch("/api/session/csrf");
    const t = await r.json();
    headers[t.headerName] = t.token;
  }
  if (body) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(body);
  }
  const r = await fetch("/api" + url, { method, headers, body });
  if (!r.ok) {
    const e = await r
      .json()
      .catch(() => ({ detail: "Ошибка соединения с сервером" }));
    if (r.status === 401) {
      $("#app").hidden = true;
      $("#login").hidden = false;
    }
    throw Error(e.detail || "Не удалось выполнить операцию");
  }
  return r.status === 204
    ? null
    : await r.text().then((t) => (t ? JSON.parse(t) : null));
}
const safe =
  (f) =>
  async (...a) => {
    try {
      await f(...a);
    } catch (e) {
      toast(e.message);
    }
  };
function metricOptions(items = metrics) {
  return items
    .map((m) => `<option value="${m.code}">${esc(m.label)}</option>`)
    .join("");
}
function metric(code) {
  return metrics.find((m) => m.code === code) || { label: code, unit: "" };
}
function readingValue(m) {
  const value = `${fmt(m.value)} ${metric(m.metric).unit}`;
  return m.heightCm == null
    ? value
    : `${fmt(m.heightCm)} см · ${value} · ИМТ ${fmtBmi(m.bmi)}`;
}
function fmtBmi(value) {
  return Number(value).toLocaleString("ru-RU", { maximumFractionDigits: 2 });
}
function criticalLimits(rule) {
  const { min, max } = metric(rule.metric);
  const limits = [];
  if (rule.criticalLowerBound >= min) limits.push(`≤ ${fmtBmi(rule.criticalLowerBound)}`);
  if (rule.criticalUpperBound <= max) limits.push(`≥ ${fmtBmi(rule.criticalUpperBound)}`);
  return limits.join(" или ") || "вне диапазона измерений";
}
function levelBadge(level = "UNKNOWN") {
  return `<span class="health-badge level-${level}">${labels[level]}</span>`;
}
function renderHealth() {
  const health = data.patient.health;
  $("#patient-health").className = `panel health-summary level-${health.level}`;
  $("#patient-health").innerHTML =
    `<div class="section-title"><h3>Состояние по последним измерениям</h3>${levelBadge(health.level)}</div>` +
    `<p>Наиболее высокий уровень среди последних значений каждого показателя за всё время.${health.unassessedCount ? ` Без оценки: ${health.unassessedCount} (нет данных или подходящих границ).` : ""}</p>` +
    `<div class="health-readings">${health.measurements.map((m) => `<div class="health-reading"><b>${m.heightCm != null ? "Рост и масса" : esc(metric(m.metric).label)}: ${esc(readingValue(m))}</b>${levelBadge(m.level)}<small>${date(m.occurredAt)}</small></div>`).join("") || '<p>Добавьте первое измерение для оценки.</p>'}</div>`;
}
async function start() {
  user = await request("/session/me");
  metrics = await request("/metrics");
  $("#login").hidden = true;
  $("#app").hidden = false;
  $("#identity").textContent =
    `${user.username} · ${{ DOCTOR: "Врач", ADMIN: "Администратор", PATIENT: "Пациент" }[user.role]}`;
  $(".today").textContent = new Date().toLocaleDateString("ru-RU", {
    dateStyle: "long",
  });
  document
    .querySelectorAll(".staff")
    .forEach((e) => (e.hidden = user.role === "PATIENT"));
  $("#add-patient").hidden = user.role === "PATIENT";
  $("#chart-metric").innerHTML = metricOptions();
  $("#rule-metric").innerHTML = metricOptions(metrics.filter((m) => m.code !== "WEIGHT"));
  $("#to").value = localDay();
  const d = new Date($("#to").value);
  d.setUTCDate(d.getUTCDate() - 13);
  $("#from").value = d.toISOString().slice(0, 10);
  await loadPeople();
}
async function loadPeople() {
  people = await request(
    "/patients?search=" + encodeURIComponent($("#search").value),
  );
  if (!people.some((p) => p.id === selected)) selected = people[0]?.id ?? null;
  renderPeople();
  await loadDetail();
}
function renderPeople() {
  $("#patients").innerHTML =
    people
      .map(
        (p) =>
          `<button class="patient-item ${p.id === selected ? "selected" : ""}" data-id="${p.id}">${esc(p.fullName)}<small>${esc(p.code)} · ${p.active ? "Наблюдение" : "Архив"}</small>${levelBadge(p.health.level)}</button>`,
      )
      .join("") || "<p>Пациенты не найдены</p>";
  document.querySelectorAll(".patient-item").forEach(
    (b) =>
      (b.onclick = safe(async () => {
        selected = Number(b.dataset.id);
        renderPeople();
        await loadDetail();
      })),
  );
}
async function loadDetail() {
  if (selected === null) {
    $("#detail").hidden = true;
    $("#empty").hidden = false;
    return;
  }
  if (!$("#from").value || !$("#to").value)
    throw Error("Укажите начало и конец периода");
  data = await request(
    `/patients/${selected}?from=${$("#from").value}&to=${$("#to").value}`,
  );
  $("#detail").hidden = false;
  $("#empty").hidden = true;
  const p = data.patient;
  const index = people.findIndex((person) => person.id === p.id);
  if (index !== -1) people[index] = p;
  renderPeople();
  renderHealth();
  $("#patient-name").textContent = p.fullName;
  $("#patient-code").textContent =
    p.code + (p.active ? " · НАБЛЮДЕНИЕ" : " · АРХИВ");
  $("#patient-meta").textContent =
    `Дата рождения: ${p.birthDate} · Врач: ${p.doctor}`;
  $("#archive").hidden = user.role === "PATIENT";
  $("#archive").textContent = p.active ? "В архив" : "Возобновить наблюдение";
  $("#add-reading").disabled = !p.active;
  $("#add-activity").disabled = !p.active;
  $("#rule-form button").disabled = !p.active;
  $("#goal-form button").disabled = !p.active;
  $("#steps").textContent = fmt(data.days.reduce((s, d) => s + d.steps, 0));
  $("#minutes").textContent = fmt(data.days.reduce((s, d) => s + d.minutes, 0));
  $("#distance").textContent =
    fmt(data.days.reduce((s, d) => s + d.distanceKm, 0)) + " км за период";
  $("#days").textContent =
    data.days.filter((d) => d.minutes > 0).length + " дней с активностью";
  $("#alert-count").textContent = data.alerts.filter(
    (a) => a.status !== "RESOLVED",
  ).length;
  $("#goal-label").textContent = fmt(p.stepGoal) + " шагов / день";
  $("#goal-form [name=steps]").value = p.stepGoal;
  $("#readings").innerHTML =
    [...data.measurements]
      .reverse()
      .map(
        (m) =>
          `<tr><td>${date(m.occurredAt)}</td><td>${m.heightCm != null ? "Рост и масса" : esc(metric(m.metric).label)}</td><td><b>${esc(readingValue(m))}</b></td><td>${levelBadge(m.level)}</td><td>${esc(m.note) || "—"}</td><td>${esc(m.author)}</td></tr>`,
      )
      .join("") || '<tr><td colspan="6">Нет измерений за период</td></tr>';
  $("#activity-rows").innerHTML =
    [...data.activities]
      .reverse()
      .map(
        (a) =>
          `<tr><td>${esc(a.day)}</td><td>${labels[a.kind]}</td><td>${fmt(a.steps)}</td><td>${a.minutes}</td><td>${fmt(a.distanceKm)}</td></tr>`,
      )
      .join("") || '<tr><td colspan="5">Нет активности за период</td></tr>';
  $("#rules").innerHTML = data.rules
    .map(
      (r) =>
        `<p>${esc(metric(r.metric).label)} (${esc(metric(r.metric).unit)}) · зелёный <b>${fmtBmi(r.lowerBound)} – ${fmtBmi(r.upperBound)}</b> · красный <b>${criticalLimits(r)}</b>.</p>`,
    )
    .join("");
  $("#audit").innerHTML =
    data.audit
      .map(
        (a) =>
          `<div class="audit-item"><div>${date(a.happenedAt)}<small>${esc(a.actor)}</small></div><div>${esc(a.detail)}<small>${esc(a.action)}</small></div></div>`,
      )
      .join("") || "<p>Изменений пока нет</p>";
  renderCharts();
  renderAlerts();
  ruleValues();
  showTab(tab);
}
function showTab(name) {
  tab = name;
  document
    .querySelectorAll(".tab")
    .forEach((e) => (e.hidden = e.id !== "tab-" + name));
  document
    .querySelectorAll("[data-tab]")
    .forEach((e) => e.classList.toggle("selected", e.dataset.tab === name));
}
function renderCharts() {
  const chartMetric = $("#chart-metric").value;
  const ms = chartMetric === "BMI"
    ? data.measurements.filter((m) => m.bmi != null).map((m) => ({ ...m, value: m.bmi }))
    : data.measurements.filter((m) => m.metric === chartMetric);
  if (!ms.length)
    $("#line-chart").innerHTML =
      '<div class="empty">Нет измерений выбранного показателя</div>';
  else {
    let lo = Math.min(...ms.map((m) => m.value)) - 5,
      hi = Math.max(...ms.map((m) => m.value)) + 5;
    const start = Date.parse(ms[0].occurredAt),
      span = Math.max(1, Date.parse(ms.at(-1).occurredAt) - start);
    const x = (i) => 42 + ((Date.parse(ms[i].occurredAt) - start) * 345) / span,
      y = (v) => 155 - ((v - lo) / (hi - lo)) * 120;
    $("#line-chart").innerHTML =
      `<svg class="chart" viewBox="0 0 410 190" role="img" aria-label="Динамика показателя">${[lo, (lo + hi) / 2, hi].map((v) => `<line class="grid" x1="42" x2="397" y1="${y(v)}" y2="${y(v)}"/><text x="0" y="${y(v) + 4}">${fmt(v)}</text>`).join("")}<path class="line" d="${ms.map((m, i) => (i ? "L" : "M") + x(i) + " " + y(m.value)).join(" ")}"/>${ms.map((m, i) => `<circle cx="${x(i)}" cy="${y(m.value)}" r="3"><title>${esc(date(m.occurredAt))}: ${m.value}</title></circle>`).join("")}<text x="42" y="180">${esc(date(ms[0].occurredAt).slice(0, 10))}</text><text x="340" y="180">${esc(date(ms.at(-1).occurredAt).slice(0, 10))}</text></svg>`;
  }
  const ds = data.days,
    max = Math.max(data.patient.stepGoal, ...ds.map((d) => d.steps)) * 1.15,
    bw = 345 / ds.length,
    y = (v) => 155 - (v / max) * 120;
  $("#bar-chart").innerHTML =
    `<svg class="chart" viewBox="0 0 410 190" role="img" aria-label="Шаги по дням"><text x="0" y="30">${fmt(max)}</text><line class="grid" x1="40" x2="400" y1="155" y2="155"/>${ds.map((d, i) => `<rect x="${42 + i * bw}" y="${y(d.steps)}" width="${Math.max(0.5, bw * 0.65)}" height="${155 - y(d.steps)}" rx="2" fill="${d.steps >= data.patient.stepGoal ? "var(--chart-main)" : "var(--chart-soft)"}"><title>${d.day}: ${d.steps} шагов · ${d.goalPercent}% цели</title></rect>`).join("")}<line class="goal" x1="40" x2="400" y1="${y(data.patient.stepGoal)}" y2="${y(data.patient.stepGoal)}"/><text x="42" y="180">${ds[0].day.slice(5)}</text><text x="350" y="180">${ds.at(-1).day.slice(5)}</text></svg>`;
}
function renderAlerts() {
  const list = data.alerts.filter(
    (a) =>
      $("#alert-filter").value === "ALL" ||
      a.status === $("#alert-filter").value,
  );
  $("#alerts").innerHTML =
    list
      .map(
        (a) =>
          `<div class="alert-item level-${a.level}"><div class="section-title"><b>${esc(metric(a.metric).label)} · ${fmtBmi(a.value)} ${esc(metric(a.metric).unit)}</b><div class="alert-badges">${levelBadge(a.level)}<span class="badge">${labels[a.status]}</span></div></div><p>${date(a.occurredAt)}${a.heightCm != null ? ` · Рост ${fmt(a.heightCm)} см, масса ${fmt(a.weightKg)} кг` : ""} · Норма при регистрации: ${fmtBmi(a.lowerBound)} – ${fmtBmi(a.upperBound)}. Красный уровень: ${criticalLimits(a)}.</p>${a.comment ? `<p>${esc(a.reviewer)}: ${esc(a.comment)}</p>` : ""}${user.role !== "PATIENT" && a.status !== "RESOLVED" ? `<button data-review="${a.id}">${a.status === "NEW" ? "Взять в работу" : "Завершить обработку"}</button>` : ""}</div>`,
      )
      .join("") || '<div class="empty">Уведомлений нет</div>';
  document.querySelectorAll("[data-review]").forEach(
    (b) =>
      (b.onclick = () => {
        const a = data.alerts.find((a) => a.id === Number(b.dataset.review));
        openModal(
          "Обработка уведомления",
          field("Комментарий", "comment", "text", 'required maxlength="1000"'),
          async (v) =>
            request(`/patients/${selected}/alerts/${a.id}`, "PUT", {
              status: a.status === "NEW" ? "ACKNOWLEDGED" : "RESOLVED",
              comment: v.comment,
              version: a.version,
            }),
        );
      }),
  );
}
function field(label, name, type = "text", attrs = "") {
  return `<label>${label}<input name="${name}" type="${type}" ${attrs}></label>`;
}
function openModal(title, fields, action) {
  $("#modal-title").textContent = title;
  $("#modal-fields").innerHTML = fields;
  $("#form-error").textContent = "";
  modalAction = action;
  $("#modal").showModal();
}
$("#modal-form").onsubmit = async (e) => {
  e.preventDefault();
  const b = $("#modal-save");
  b.disabled = true;
  try {
    const v = Object.fromEntries(new FormData(e.target));
    await modalAction(v);
    $("#modal").close();
    await loadPeople();
    toast("Изменения сохранены");
  } catch (e) {
    $("#form-error").textContent = e.message;
  } finally {
    b.disabled = false;
  }
};
$("#close-modal").onclick = () => $("#modal").close();
$("#add-reading").onclick = () => {
  const local = new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 16);
  const readingOptions = metrics
    .filter((m) => m.code !== "BMI")
    .map((m) => m.code === "WEIGHT" ? { ...m, label: "Рост и масса" } : m);
  openModal(
    "Новое измерение",
    `<label>Показатель<select name="metric">${metricOptions(readingOptions)}</select></label>` +
      `<div id="height-field" hidden>${field("Рост, см", "heightCm", "number", 'min="30" max="300" step="any" required disabled')}</div>` +
      field('<span id="reading-value-label">Значение</span>', "value", "number", 'required step="any"') +
      field(
        "Дата и время (часовой пояс устройства)",
        "occurredAt",
        "datetime-local",
        `required value="${local}"`,
      ) +
      field("Комментарий", "note", "text", 'maxlength="500"'),
    (v) =>
      request(`/patients/${selected}/measurements`, "POST", {
        ...v,
        value: Number(v.value),
        ...(v.metric === "WEIGHT" ? { heightCm: Number(v.heightCm) } : {}),
        occurredAt: new Date(v.occurredAt).toISOString(),
      }),
  );
  const measureType = $("#modal-fields [name=metric]");
  const updateReadingFields = () => {
    const paired = measureType.value === "WEIGHT";
    $("#height-field").hidden = !paired;
    $("#height-field input").disabled = !paired;
    $("#reading-value-label").textContent = paired ? "Масса, кг" : "Значение";
  };
  measureType.onchange = updateReadingFields;
  updateReadingFields();
};
$("#add-activity").onclick = () =>
  openModal(
    "Добавить активность",
    field(
      "Дата",
      "day",
      "date",
      `required value="${localDay()}" max="${localDay()}"`,
    ) +
      `<label>Занятие<select name="kind"><option value="WALK">Ходьба</option><option value="RUN">Бег</option><option value="CYCLE">Велосипед</option><option value="OTHER">Другое</option></select></label>` +
      field(
        "Длительность, минут",
        "minutes",
        "number",
        'required min="1" max="1440"',
      ) +
      field(
        "Количество шагов",
        "steps",
        "number",
        'required min="0" max="200000" value="0"',
      ) +
      field(
        "Расстояние, км",
        "distanceKm",
        "number",
        'required min="0" max="1000" step="0.01" value="0"',
      ),
    (v) =>
      request(`/patients/${selected}/activities`, "POST", {
        ...v,
        minutes: Number(v.minutes),
        steps: Number(v.steps),
        distanceKm: Number(v.distanceKm),
      }),
  );
$("#add-patient").onclick = safe(async () => {
  const doctors = await request("/doctors");
  openModal(
    "Новая карта пациента",
    field("Фамилия и имя", "fullName", "text", 'required maxlength="120"') +
      field(
        "Код карты",
        "code",
        "text",
        'required pattern="[A-Za-z0-9-]{3,30}" placeholder="PM-005"',
      ) +
      field(
        "Дата рождения",
        "birthDate",
        "date",
        `required max="${localDay()}"`,
      ) +
      `<label>Наблюдающий врач<select name="doctorId">${doctors
        .filter((d) => user.role === "ADMIN" || d.id === user.id)
        .map((d) => `<option value="${d.id}">${esc(d.username)}</option>`)
        .join("")}</select></label>` +
      field(
        "Дневная цель по шагам",
        "stepGoal",
        "number",
        'required min="100" max="100000" value="6000"',
      ),
    async (v) => {
      const p = await request("/patients", "POST", {
        ...v,
        doctorId: Number(v.doctorId),
        stepGoal: Number(v.stepGoal),
      });
      selected = p.id;
      $("#search").value = "";
    },
  );
});
function ruleValues() {
  const r = data.rules.find((r) => r.metric === $("#rule-metric").value);
  $("#rule-form [name=lowerBound]").value = r?.lowerBound ?? "";
  $("#rule-form [name=upperBound]").value = r?.upperBound ?? "";
  $("#rule-form [name=criticalLowerBound]").value = r?.criticalLowerBound ?? "";
  $("#rule-form [name=criticalUpperBound]").value = r?.criticalUpperBound ?? "";
}
$("#rule-metric").onchange = ruleValues;
$("#rule-form").onsubmit = safe(async (e) => {
  e.preventDefault();
  const v = Object.fromEntries(new FormData(e.target));
  await request(`/patients/${selected}/rule`, "PUT", {
    metric: v.metric,
    lowerBound: Number(v.lowerBound),
    upperBound: Number(v.upperBound),
    criticalLowerBound: v.criticalLowerBound === "" ? null : Number(v.criticalLowerBound),
    criticalUpperBound: v.criticalUpperBound === "" ? null : Number(v.criticalUpperBound),
  });
  await loadDetail();
  toast("Границы сохранены");
});
$("#goal-form").onsubmit = safe(async (e) => {
  e.preventDefault();
  await request(`/patients/${selected}/goal`, "PUT", {
    steps: Number(e.target.steps.value),
    version: data.patient.version,
  });
  await loadDetail();
  toast("Цель сохранена");
});
$("#archive").onclick = safe(async () => {
  await request(`/patients/${selected}/status`, "PUT", {
    active: !data.patient.active,
    version: data.patient.version,
  });
  await loadPeople();
  toast("Статус карты изменен");
});
$("#apply").onclick = safe(loadDetail);
$("#chart-metric").onchange = renderCharts;
$("#alert-filter").onchange = renderAlerts;
document
  .querySelectorAll("[data-tab]")
  .forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));
let searchTimer;
$("#search").oninput = () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(safe(loadPeople), 300);
};
$("#export").onclick = () => {
  const quote = (v) =>
    '"' +
    String(v ?? "")
      .replace(/^[=+@-]/, "'$&")
      .replace(/"/g, '""') +
    '"';
  const rows = [
    ["Дата", "Показатель", "Значение", "Единица", "Уровень", "Комментарий", "Автор", "Рост, см", "ИМТ"],
    ...data.measurements.map((m) => [
      date(m.occurredAt),
      metric(m.metric).label,
      m.value,
      metric(m.metric).unit,
      labels[m.level],
      m.note,
      m.author,
      m.heightCm,
      m.bmi,
    ]),
  ];
  const url = URL.createObjectURL(
    new Blob(
      ["\ufeff" + rows.map((r) => r.map(quote).join(";")).join("\r\n")],
      { type: "text/csv;charset=utf-8" },
    ),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = `measurements-${data.patient.code}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};
$("#login-form").onsubmit = async (e) => {
  e.preventDefault();
  try {
    const t = await (await fetch("/api/session/csrf")).json();
    const r = await fetch("/api/session/login", {
      method: "POST",
      headers: { [t.headerName]: t.token },
      body: new URLSearchParams(new FormData(e.target)),
    });
    if (!r.ok) throw Error("Неверный логин или пароль");
    $("#login-error").textContent = "";
    selected = null;
    tab = "observations";
    await start();
  } catch (e) {
    $("#login-error").textContent = e.message;
  }
};
$("#logout").onclick = safe(async () => {
  await request("/session/logout", "POST");
  $("#app").hidden = true;
  $("#login").hidden = false;
  data = null;
  selected = null;
  $("#search").value = "";
});
start().catch(() => {
  $("#app").hidden = true;
  $("#login").hidden = false;
});
