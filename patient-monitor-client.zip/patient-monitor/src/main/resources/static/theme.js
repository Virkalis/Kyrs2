// Применяем сохраненную тему до отрисовки страницы.
(() => {
  let theme = "light";
  try {
    theme = localStorage.getItem("pulse-theme") === "dark" ? "dark" : "light";
  } catch (_) { /* Тема работает и при недоступном локальном хранилище. */ }
  document.documentElement.dataset.theme = theme;
  document.addEventListener("DOMContentLoaded", () => {
    const button = document.getElementById("theme-toggle");
    function update() {
      const dark = document.documentElement.dataset.theme === "dark";
      button.textContent = dark ? "☀ Светлая тема" : "☾ Тёмная тема";
      button.setAttribute("aria-pressed", String(dark));
      button.setAttribute("aria-label", dark ? "Включить светлую тему" : "Включить тёмную тему");
    }
    button.addEventListener("click", () => {
      theme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = theme;
      try { localStorage.setItem("pulse-theme", theme); } catch (_) {}
      update();
    });
    update();
  });
})();
