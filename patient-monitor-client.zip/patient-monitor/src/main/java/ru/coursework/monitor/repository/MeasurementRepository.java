package ru.coursework.monitor.repository;

import ru.coursework.monitor.domain.*;

public interface MeasurementRepository
    extends org.springframework.data.jpa.repository.JpaRepository<Measurement, Long> {
  @org.springframework.data.jpa.repository.Query("""
      select m from Measurement m where m.patient.id = :patientId
      and not exists (select newer.id from Measurement newer
        where newer.patient.id = :patientId and newer.metric = m.metric
        and (newer.occurredAt > m.occurredAt
          or (newer.occurredAt = m.occurredAt and newer.id > m.id)))
      order by m.metric
      """)
  java.util.List<Measurement> findLatestByPatientId(Long patientId);

  java.util.List<Measurement>
      findByPatientIdAndOccurredAtGreaterThanEqualAndOccurredAtLessThanOrderByOccurredAtAsc(
          Long id, java.time.Instant start, java.time.Instant end);
}
