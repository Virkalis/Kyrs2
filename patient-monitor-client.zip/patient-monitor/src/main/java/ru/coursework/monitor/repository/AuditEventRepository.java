package ru.coursework.monitor.repository;

import ru.coursework.monitor.domain.*;

public interface AuditEventRepository
    extends org.springframework.data.jpa.repository.JpaRepository<AuditEvent, Long> {
  java.util.List<AuditEvent> findTop100ByPatientIdOrderByIdDesc(Long patientId);
}
