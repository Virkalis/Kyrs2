package ru.coursework.monitor.domain;

import jakarta.persistence.*;

@Entity
public class Patient {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  @Version public long version;

  @Column(nullable = false)
  public String fullName;

  @Column(nullable = false, unique = true)
  public String code;

  @Column(nullable = false)
  public java.time.LocalDate birthDate;

  @ManyToOne(optional = false)
  public Account doctor;

  @OneToOne public Account account;
  public int stepGoal = 6000;
  public boolean active = true;
}
