package ru.coursework.monitor.repository;

import ru.coursework.monitor.domain.*;

public interface AlertRepository
    extends org.springframework.data.jpa.repository.JpaRepository<Alert, Long> {
  java.util.List<Alert> findByMeasurementPatientIdOrderByIdDesc(Long patientId);
}
