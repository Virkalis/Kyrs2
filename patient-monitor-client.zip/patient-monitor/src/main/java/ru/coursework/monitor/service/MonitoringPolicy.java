package ru.coursework.monitor.service;

import java.time.*;
import ru.coursework.monitor.domain.Metric;
import ru.coursework.monitor.domain.HealthLevel;

/** Чистые правила контроля ввода, периода и границ мониторинга. */
public final class MonitoringPolicy {
  public static final ZoneId ZONE = ZoneId.of("Europe/Moscow");
  public static final int MIN_HEIGHT_CM = 30;
  public static final int MAX_HEIGHT_CM = 300;

  private MonitoringPolicy() {}

  public static boolean outside(double value, double low, double high) {
    return value < low || value > high;
  }

  // Учебное начальное правило: отступ в половину ширины нормального интервала.
  public static double criticalLow(double low, double high, Double configured) {
    return configured != null ? configured : low - (high - low) / 2;
  }

  public static double criticalHigh(double low, double high, Double configured) {
    return configured != null ? configured : high + (high - low) / 2;
  }

  public static HealthLevel level(
      double value, double low, double high, Double criticalLow, Double criticalHigh) {
    if (!outside(value, low, high)) return HealthLevel.GREEN;
    if (value <= criticalLow(low, high, criticalLow)
        || value >= criticalHigh(low, high, criticalHigh)) return HealthLevel.RED;
    return HealthLevel.YELLOW;
  }

  public static void criticalBounds(double low, double high, Double criticalLow, Double criticalHigh) {
    if (criticalLow != null && (!Double.isFinite(criticalLow) || criticalLow >= low)
        || criticalHigh != null && (!Double.isFinite(criticalHigh) || criticalHigh <= high))
      throw new BusinessException(
          400, "Красная нижняя граница должна быть ниже нормы, а красная верхняя — выше нормы");
  }

  public static void reading(Metric metric, double value) {
    if (!Double.isFinite(value) || value < metric.min || value > metric.max)
      throw new BusinessException(
          400, "Значение вне технического диапазона: " + metric.min + "–" + metric.max);
  }

  public static void height(Metric metric, Double heightCm) {
    if (metric != Metric.WEIGHT) {
      if (heightCm != null) throw new BusinessException(400, "Рост указывается вместе с массой");
      return;
    }
    if (heightCm == null || !Double.isFinite(heightCm)
        || heightCm < MIN_HEIGHT_CM || heightCm > MAX_HEIGHT_CM)
      throw new BusinessException(400, "Укажите рост в сантиметрах от 30 до 300");
  }

  public static void period(LocalDate from, LocalDate to) {
    if (from == null
        || to == null
        || to.isBefore(from)
        || java.time.temporal.ChronoUnit.DAYS.between(from, to) > 365)
      throw new BusinessException(400, "Период должен составлять от 1 до 366 дней");
  }

  public static void time(Instant time, Instant now) {
    if (time == null || time.isAfter(now) || time.isBefore(Instant.parse("2000-01-01T00:00:00Z")))
      throw new BusinessException(400, "Недопустимое время измерения");
  }

  public static void transition(String current, String next) {
    if (!(current.equals("NEW") && next.equals("ACKNOWLEDGED")
        || current.equals("ACKNOWLEDGED") && next.equals("RESOLVED")))
      throw new BusinessException(409, "Недопустимый переход состояния уведомления");
  }
}
