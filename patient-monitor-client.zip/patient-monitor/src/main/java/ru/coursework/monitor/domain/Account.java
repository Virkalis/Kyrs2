package ru.coursework.monitor.domain;

import jakarta.persistence.*;

@Entity
@Table(name = "accounts")
public class Account {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  @Column(nullable = false, unique = true)
  public String username;

  @com.fasterxml.jackson.annotation.JsonIgnore
  @Column(nullable = false)
  public String passwordHash;

  @Column(nullable = false)
  public String role;
}
