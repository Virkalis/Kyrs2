package ru.coursework.monitor.domain;

/** Уровень отклонения от индивидуальных границ наблюдения. */
public enum HealthLevel {
  UNKNOWN, GREEN, YELLOW, RED
}
