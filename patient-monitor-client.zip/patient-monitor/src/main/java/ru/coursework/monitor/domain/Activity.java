package ru.coursework.monitor.domain;

import jakarta.persistence.*;

@Entity
public class Activity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  @ManyToOne(optional = false)
  public Patient patient;

  @Column(name = "activity_day", nullable = false)
  public java.time.LocalDate day;

  @Column(nullable = false)
  public String kind;

  public int minutes;
  public int steps;
  public double distanceKm;

  @Column(nullable = false)
  public String author;
}
