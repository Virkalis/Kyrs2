package ru.coursework.monitor.domain;

import jakarta.persistence.*;

@Entity
public class AuditEvent {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  @Column(nullable = false)
  public java.time.Instant happenedAt;

  @Column(nullable = false)
  public String actor;

  @Column(nullable = false)
  public String action;

  public Long patientId;

  @Column(length = 1000)
  public String detail;
}
