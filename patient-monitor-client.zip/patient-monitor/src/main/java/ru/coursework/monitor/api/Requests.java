package ru.coursework.monitor.api;

import jakarta.validation.constraints.*;
import java.time.*;
import ru.coursework.monitor.domain.Metric;

public final class Requests {
  public record PatientInput(
      @NotBlank @Size(max = 120) String fullName,
      @NotBlank @Pattern(regexp = "[A-Za-z0-9-]{3,30}") String code,
      @NotNull @PastOrPresent LocalDate birthDate,
      @NotNull Long doctorId,
      @Min(100) @Max(100000) int stepGoal) {}

  public record Reading(
      @NotNull Metric metric,
      @NotNull Double value,
      @NotNull Instant occurredAt,
      @Size(max = 500) String note,
      Double heightCm) {}

  public record ActivityInput(
      @NotNull @PastOrPresent LocalDate day,
      @Pattern(regexp = "WALK|RUN|CYCLE|OTHER") @NotNull String kind,
      @Min(1) @Max(1440) int minutes,
      @Min(0) @Max(200000) int steps,
      @DecimalMin("0") @DecimalMax("1000") double distanceKm) {}

  public record Rule(
      @NotNull Metric metric,
      @NotNull Double lowerBound,
      @NotNull Double upperBound,
      Double criticalLowerBound,
      Double criticalUpperBound) {}

  public record Review(
      @NotBlank String status, @NotBlank @Size(max = 1000) String comment, @Min(0) long version) {}

  public record Goal(@Min(100) @Max(100000) int steps, @Min(0) long version) {}

  public record Archive(boolean active, @Min(0) long version) {}
}
