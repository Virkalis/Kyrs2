package ru.coursework.monitor.repository;

import ru.coursework.monitor.domain.*;

public interface MonitoringRuleRepository
    extends org.springframework.data.jpa.repository.JpaRepository<MonitoringRule, Long> {
  java.util.Optional<MonitoringRule> findByPatientIdAndMetric(Long patientId, Metric metric);

  java.util.List<MonitoringRule> findByPatientId(Long patientId);
}
