package ru.coursework.monitor.repository;

import ru.coursework.monitor.domain.*;

public interface ActivityRepository
    extends org.springframework.data.jpa.repository.JpaRepository<Activity, Long> {
  java.util.List<Activity> findByPatientIdAndDayBetweenOrderByDayAsc(
      Long id, java.time.LocalDate start, java.time.LocalDate end);
}
