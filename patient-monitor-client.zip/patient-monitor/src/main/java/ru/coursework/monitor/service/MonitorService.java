package ru.coursework.monitor.service;

import java.time.*;
import java.util.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.coursework.monitor.api.Requests.*;
import ru.coursework.monitor.domain.*;
import ru.coursework.monitor.repository.*;

/** Прикладные операции мониторинга; проверка принадлежности данных выполняется на сервере. */
@Service
@Transactional
public class MonitorService {
  private final AccountRepository accounts;
  private final PatientRepository patients;
  private final MeasurementRepository measurements;
  private final ActivityRepository activities;
  private final MonitoringRuleRepository rules;
  private final AlertRepository alerts;
  private final AuditEventRepository audit;

  public MonitorService(
      AccountRepository accounts,
      PatientRepository patients,
      MeasurementRepository measurements,
      ActivityRepository activities,
      MonitoringRuleRepository rules,
      AlertRepository alerts,
      AuditEventRepository audit) {
    this.accounts = accounts;
    this.patients = patients;
    this.measurements = measurements;
    this.activities = activities;
    this.rules = rules;
    this.alerts = alerts;
    this.audit = audit;
  }

  public Account current() {
    return accounts
        .findByUsername(SecurityContextHolder.getContext().getAuthentication().getName())
        .orElseThrow(() -> new BusinessException(401, "Необходим вход"));
  }

  private boolean allowed(Patient p, Account u) {
    return u.role.equals("ADMIN")
        || u.role.equals("DOCTOR") && p.doctor.id.equals(u.id)
        || p.account != null && p.account.id.equals(u.id);
  }

  private void staff() {
    if (current().role.equals("PATIENT"))
      throw new BusinessException(403, "Операция доступна сотруднику");
  }

  private Patient patient(Long id, boolean write) {
    Patient p =
        (write ? patients.lockById(id) : patients.findById(id))
            .orElseThrow(() -> new BusinessException(404, "Пациент не найден"));
    if (!allowed(p, current())) throw new BusinessException(403, "Нет доступа к карте пациента");
    return p;
  }

  private void active(Patient p) {
    if (!p.active) throw new BusinessException(409, "Карта находится в архиве");
  }

  private void event(Patient p, String action, String detail) {
    AuditEvent e = new AuditEvent();
    e.actor = current().username;
    e.happenedAt = Instant.now();
    e.patientId = p.id;
    e.action = action;
    e.detail = detail;
    audit.save(e);
  }

  public Map<String, Object> patientView(Patient p) {
    return patientView(p, effectiveRules(p.id));
  }

  private Map<String, Object> patientView(Patient p, Map<Metric, MonitoringRule> configured) {
    return Map.of(
        "id",
        p.id,
        "version",
        p.version,
        "fullName",
        p.fullName,
        "code",
        p.code,
        "birthDate",
        p.birthDate,
        "doctor",
        p.doctor.username,
        "stepGoal",
        p.stepGoal,
        "active",
        p.active,
        "health",
        health(p.id, configured));
  }

  private HealthLevel level(Measurement m, MonitoringRule rule, Double value) {
    if (value == null) return HealthLevel.UNKNOWN;
    int defaultAge = rule.metric == Metric.BMI ? 20 : 18;
    LocalDate day = m.occurredAt.atZone(MonitoringPolicy.ZONE).toLocalDate();
    if (rule.id == null && day.isBefore(m.patient.birthDate.plusYears(defaultAge)))
      return HealthLevel.UNKNOWN;
    return MonitoringPolicy.level(value, rule.lowerBound, rule.upperBound,
        rule.criticalLowerBound, rule.criticalUpperBound);
  }

  private Map<String, Object> measurementView(Measurement m, Map<Metric, MonitoringRule> configured) {
    Double bmi = m.bmi();
    Double value = m.metric == Metric.WEIGHT ? bmi : Double.valueOf(m.value);
    Map<String, Object> view = new LinkedHashMap<>();
    view.put("metric", m.metric);
    view.put("value", m.value);
    view.put("occurredAt", m.occurredAt);
    view.put("level", level(m, configured.get(m.metric.assessmentMetric()), value));
    if (bmi != null) {
      view.put("heightCm", m.heightCm);
      view.put("bmi", bmi);
    }
    return view;
  }

  private Map<Metric, MonitoringRule> effectiveRules(Long id) {
    Map<Metric, MonitoringRule> configured = new EnumMap<>(Metric.class);
    rules.findByPatientId(id).stream()
        .filter(r -> r.metric != Metric.WEIGHT)
        .forEach(r -> configured.put(r.metric, r));
    for (Metric metric : Metric.values()) {
      if (metric != Metric.WEIGHT) configured.computeIfAbsent(metric, MonitoringRule::defaults);
    }
    return configured;
  }

  private Map<String, Object> health(Long id, Map<Metric, MonitoringRule> configured) {
    List<Measurement> latest = measurements.findLatestByPatientId(id);
    HealthLevel overall = HealthLevel.UNKNOWN;
    Set<Metric> unassessed = EnumSet.noneOf(Metric.class);
    configured.values().stream().filter(r -> r.id != null).forEach(r -> unassessed.add(r.metric));
    List<Map<String, Object>> values = new ArrayList<>();
    for (Measurement m : latest) {
      Map<String, Object> view = measurementView(m, configured);
      HealthLevel current = (HealthLevel) view.get("level");
      Metric metric = m.metric.assessmentMetric();
      if (current != HealthLevel.UNKNOWN) unassessed.remove(metric);
      else unassessed.add(metric);
      if (current.ordinal() > overall.ordinal()) overall = current;
      values.add(view);
    }
    return Map.of("level", overall, "unassessedCount", unassessed.size(), "measurements", values);
  }

  @Transactional(readOnly = true)
  public List<Map<String, Object>> patients(String search) {
    Account u = current();
    String q = search.toLowerCase(Locale.ROOT).trim();
    return patients.findAll().stream()
        .filter(p -> allowed(p, u))
        .filter(p -> (p.fullName + " " + p.code).toLowerCase(Locale.ROOT).contains(q))
        .sorted(Comparator.comparing(p -> p.fullName))
        .map(this::patientView)
        .toList();
  }

  @Transactional(readOnly = true)
  public List<Map<String, Object>> doctors() {
    staff();
    return accounts.findByRole("DOCTOR").stream()
        .map(a -> Map.<String, Object>of("id", a.id, "username", a.username))
        .toList();
  }

  public Map<String, Object> createPatient(PatientInput input) {
    staff();
    Account user = current();
    Account doctor =
        accounts
            .findById(input.doctorId())
            .filter(a -> a.role.equals("DOCTOR"))
            .orElseThrow(() -> new BusinessException(400, "Врач не найден"));
    if (user.role.equals("DOCTOR") && !doctor.id.equals(user.id))
      throw new BusinessException(403, "Врач создает карты только для своего наблюдения");
    if (input.birthDate().isBefore(LocalDate.now().minusYears(130)))
      throw new BusinessException(400, "Проверьте дату рождения");
    Patient p = new Patient();
    p.fullName = input.fullName().trim();
    p.code = input.code().toUpperCase(Locale.ROOT);
    p.birthDate = input.birthDate();
    p.doctor = doctor;
    p.stepGoal = input.stepGoal();
    patients.saveAndFlush(p);
    event(p, "PATIENT_CREATED", p.code);
    return patientView(p);
  }

  public void goal(Long id, Goal input) {
    staff();
    Patient p = patient(id, true);
    active(p);
    if (p.version != input.version())
      throw new BusinessException(409, "Карта изменена. Обновите страницу");
    p.stepGoal = input.steps();
    event(p, "GOAL_CHANGED", "Шаги: " + p.stepGoal);
  }

  public void archive(Long id, Archive input) {
    staff();
    Patient p = patient(id, true);
    if (p.version != input.version())
      throw new BusinessException(409, "Карта изменена. Обновите страницу");
    p.active = input.active();
    event(p, "PATIENT_STATUS", p.active ? "Наблюдение" : "Архив");
  }

  public Long reading(Long id, Reading input) {
    Patient p = patient(id, true);
    active(p);
    if (input.metric() == Metric.BMI)
      throw new BusinessException(400, "Для расчёта ИМТ введите рост и массу");
    MonitoringPolicy.reading(input.metric(), input.value());
    MonitoringPolicy.height(input.metric(), input.heightCm());
    MonitoringPolicy.time(input.occurredAt(), Instant.now());
    Measurement m = new Measurement();
    m.patient = p;
    m.metric = input.metric();
    m.value = input.value();
    m.heightCm = input.heightCm();
    m.occurredAt = input.occurredAt();
    m.registeredAt = Instant.now();
    m.author = current().username;
    m.note = input.note();
    measurements.save(m);
    MonitoringRule r = effectiveRules(id).get(m.metric.assessmentMetric());
    Double bmi = m.bmi();
    HealthLevel level = level(m, r, bmi != null ? bmi : m.value);
    if (level == HealthLevel.YELLOW || level == HealthLevel.RED) {
      Alert a = new Alert();
      a.measurement = m;
      a.lowerBound = r.lowerBound;
      a.upperBound = r.upperBound;
      a.criticalLowerBound = MonitoringPolicy.criticalLow(
          r.lowerBound, r.upperBound, r.criticalLowerBound);
      a.criticalUpperBound = MonitoringPolicy.criticalHigh(
          r.lowerBound, r.upperBound, r.criticalUpperBound);
      alerts.save(a);
    }
    String detail = bmi == null ? m.metric + ": " + m.value
        : "Рост: " + m.heightCm + " см, масса: " + m.value + " кг, ИМТ: " + bmi;
    event(p, "MEASUREMENT_ADDED", detail);
    return m.id;
  }

  public Long activity(Long id, ActivityInput input) {
    Patient p = patient(id, true);
    active(p);
    if (input.day().isBefore(LocalDate.of(2000, 1, 1)))
      throw new BusinessException(400, "Недопустимая дата активности");
    int total =
        activities.findByPatientIdAndDayBetweenOrderByDayAsc(id, input.day(), input.day()).stream()
            .mapToInt(a -> a.minutes)
            .sum();
    if (total + input.minutes() > 1440)
      throw new BusinessException(409, "Суммарная активность за день превышает 1440 минут");
    Activity a = new Activity();
    a.patient = p;
    a.day = input.day();
    a.kind = input.kind();
    a.minutes = input.minutes();
    a.steps = input.steps();
    a.distanceKm = input.distanceKm();
    a.author = current().username;
    activities.save(a);
    event(p, "ACTIVITY_ADDED", a.kind + ", " + a.steps + " шагов");
    return a.id;
  }

  public void rule(Long id, Rule input) {
    staff();
    Patient p = patient(id, true);
    active(p);
    if (input.metric() == Metric.WEIGHT)
      throw new BusinessException(400, "Для оценки массы настройте границы ИМТ");
    MonitoringPolicy.reading(input.metric(), input.lowerBound());
    MonitoringPolicy.reading(input.metric(), input.upperBound());
    if (input.lowerBound() >= input.upperBound())
      throw new BusinessException(400, "Нижняя граница должна быть меньше верхней");
    MonitoringPolicy.criticalBounds(input.lowerBound(), input.upperBound(),
        input.criticalLowerBound(), input.criticalUpperBound());
    MonitoringRule r =
        rules.findByPatientIdAndMetric(id, input.metric()).orElseGet(MonitoringRule::new);
    r.patient = p;
    r.metric = input.metric();
    r.lowerBound = input.lowerBound();
    r.upperBound = input.upperBound();
    r.criticalLowerBound = input.criticalLowerBound();
    r.criticalUpperBound = input.criticalUpperBound();
    rules.save(r);
    event(p, "RULE_CHANGED", r.metric + ": норма " + r.lowerBound + "–" + r.upperBound
        + "; красный ≤ " + MonitoringPolicy.criticalLow(r.lowerBound, r.upperBound, r.criticalLowerBound)
        + " или ≥ " + MonitoringPolicy.criticalHigh(r.lowerBound, r.upperBound, r.criticalUpperBound));
  }

  public void review(Long id, Long alertId, Review input) {
    staff();
    patient(id, true);
    Alert a =
        alerts
            .findById(alertId)
            .filter(x -> x.measurement.patient.id.equals(id))
            .orElseThrow(() -> new BusinessException(404, "Уведомление не найдено"));
    if (a.version != input.version()) throw new BusinessException(409, "Уведомление уже изменено");
    MonitoringPolicy.transition(a.status, input.status());
    a.status = input.status();
    a.comment = input.comment().trim();
    if (a.comment.isEmpty()) throw new BusinessException(400, "Требуется комментарий");
    a.reviewer = current().username;
    a.reviewedAt = Instant.now();
    event(a.measurement.patient, "ALERT_" + a.status, "Уведомление №" + a.id + ": " + a.comment);
  }

  @Transactional(readOnly = true)
  public Map<String, Object> detail(Long id, LocalDate from, LocalDate to) {
    Patient p = patient(id, false);
    MonitoringPolicy.period(from, to);
    List<Measurement> ms =
        measurements
            .findByPatientIdAndOccurredAtGreaterThanEqualAndOccurredAtLessThanOrderByOccurredAtAsc(
                id,
                from.atStartOfDay(MonitoringPolicy.ZONE).toInstant(),
                to.plusDays(1).atStartOfDay(MonitoringPolicy.ZONE).toInstant());
    List<Activity> acts = activities.findByPatientIdAndDayBetweenOrderByDayAsc(id, from, to);
    List<Map<String, Object>> days = new ArrayList<>();
    for (LocalDate d = from; !d.isAfter(to); d = d.plusDays(1)) {
      LocalDate day = d;
      List<Activity> items = acts.stream().filter(a -> a.day.equals(day)).toList();
      int steps = items.stream().mapToInt(a -> a.steps).sum();
      days.add(
          Map.of(
              "day",
              d,
              "steps",
              steps,
              "minutes",
              items.stream().mapToInt(a -> a.minutes).sum(),
              "distanceKm",
              items.stream().mapToDouble(a -> a.distanceKm).sum(),
              "goalPercent",
              Math.round(100.0 * steps / p.stepGoal)));
    }
    Map<String, Object> result = new LinkedHashMap<>();
    Map<Metric, MonitoringRule> configured = effectiveRules(id);
    result.put("patient", patientView(p, configured));
    result.put(
        "measurements",
        ms.stream()
            .map(m -> {
              Map<String, Object> view = measurementView(m, configured);
              view.put("id", m.id);
              view.put("author", m.author);
              view.put("note", Objects.toString(m.note, ""));
              return view;
            })
            .toList());
    result.put(
        "activities",
        acts.stream()
            .map(
                a ->
                    Map.of(
                        "id",
                        a.id,
                        "day",
                        a.day,
                        "kind",
                        a.kind,
                        "steps",
                        a.steps,
                        "minutes",
                        a.minutes,
                        "distanceKm",
                        a.distanceKm))
            .toList());
    result.put("days", days);
    result.put(
        "rules",
        configured.values().stream()
            .map(
                r ->
                    Map.of(
                        "metric", r.metric, "lowerBound", r.lowerBound, "upperBound", r.upperBound,
                        "criticalLowerBound", MonitoringPolicy.criticalLow(
                            r.lowerBound, r.upperBound, r.criticalLowerBound),
                        "criticalUpperBound", MonitoringPolicy.criticalHigh(
                            r.lowerBound, r.upperBound, r.criticalUpperBound)))
            .toList());
    result.put(
        "alerts",
        alerts.findByMeasurementPatientIdOrderByIdDesc(id).stream()
            .map(
                a -> {
                  Map<String, Object> v = new LinkedHashMap<>();
                  v.put("id", a.id);
                  v.put("version", a.version);
                  v.put("status", a.status);
                  Double bmi = a.measurement.bmi();
                  v.put("metric", bmi != null ? Metric.BMI : a.measurement.metric);
                  double value = bmi != null ? bmi : a.measurement.value;
                  v.put("value", value);
                  if (bmi != null) {
                    v.put("heightCm", a.measurement.heightCm);
                    v.put("weightKg", a.measurement.value);
                  }
                  v.put("occurredAt", a.measurement.occurredAt);
                  v.put("lowerBound", a.lowerBound);
                  v.put("upperBound", a.upperBound);
                  v.put("criticalLowerBound", MonitoringPolicy.criticalLow(
                      a.lowerBound, a.upperBound, a.criticalLowerBound));
                  v.put("criticalUpperBound", MonitoringPolicy.criticalHigh(
                      a.lowerBound, a.upperBound, a.criticalUpperBound));
                  v.put("level", MonitoringPolicy.level(value,
                      a.lowerBound, a.upperBound, a.criticalLowerBound, a.criticalUpperBound));
                  v.put("comment", Objects.toString(a.comment, ""));
                  v.put("reviewer", Objects.toString(a.reviewer, ""));
                  return v;
                })
            .toList());
    result.put(
        "audit",
        current().role.equals("PATIENT")
            ? List.of()
            : audit.findTop100ByPatientIdOrderByIdDesc(id));
    return result;
  }
}
