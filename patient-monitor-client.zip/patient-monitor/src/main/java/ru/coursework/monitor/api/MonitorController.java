package ru.coursework.monitor.api;

import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.*;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;
import ru.coursework.monitor.api.Requests.*;
import ru.coursework.monitor.domain.Metric;
import ru.coursework.monitor.service.MonitorService;

@RestController
@RequestMapping("/api")
public class MonitorController {
  private final MonitorService service;

  public MonitorController(MonitorService service) {
    this.service = service;
  }

  @GetMapping("/session/csrf")
  public Map<String, String> csrf(CsrfToken token) {
    return Map.of("token", token.getToken(), "headerName", token.getHeaderName());
  }

  @GetMapping("/session/me")
  public Map<String, Object> me() {
    var u = service.current();
    return Map.of("id", u.id, "username", u.username, "role", u.role);
  }

  @GetMapping("/metrics")
  public Object metrics() {
    return Arrays.stream(Metric.values())
        .map(
            m ->
                Map.of(
                    "code", m.name(), "label", m.label, "unit", m.unit, "min", m.min, "max", m.max))
        .toList();
  }

  @GetMapping("/doctors")
  public Object doctors() {
    return service.doctors();
  }

  @GetMapping("/patients")
  public Object patients(@RequestParam(defaultValue = "") String search) {
    return service.patients(search);
  }

  @PostMapping("/patients")
  @ResponseStatus(org.springframework.http.HttpStatus.CREATED)
  public Object create(@Valid @RequestBody PatientInput input) {
    return service.createPatient(input);
  }

  @GetMapping("/patients/{id}")
  public Object detail(
      @PathVariable Long id, @RequestParam LocalDate from, @RequestParam LocalDate to) {
    return service.detail(id, from, to);
  }

  @PostMapping("/patients/{id}/measurements")
  @ResponseStatus(org.springframework.http.HttpStatus.CREATED)
  public Object reading(@PathVariable Long id, @Valid @RequestBody Reading input) {
    return Map.of("id", service.reading(id, input));
  }

  @PostMapping("/patients/{id}/activities")
  @ResponseStatus(org.springframework.http.HttpStatus.CREATED)
  public Object activity(@PathVariable Long id, @Valid @RequestBody ActivityInput input) {
    return Map.of("id", service.activity(id, input));
  }

  @PutMapping("/patients/{id}/rule")
  public void rule(@PathVariable Long id, @Valid @RequestBody Rule input) {
    service.rule(id, input);
  }

  @PutMapping("/patients/{id}/goal")
  public void goal(@PathVariable Long id, @Valid @RequestBody Goal input) {
    service.goal(id, input);
  }

  @PutMapping("/patients/{id}/status")
  public void archive(@PathVariable Long id, @Valid @RequestBody Archive input) {
    service.archive(id, input);
  }

  @PutMapping("/patients/{id}/alerts/{alertId}")
  public void review(
      @PathVariable Long id, @PathVariable Long alertId, @Valid @RequestBody Review input) {
    service.review(id, alertId, input);
  }
}
