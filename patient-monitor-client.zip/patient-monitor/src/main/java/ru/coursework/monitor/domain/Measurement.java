package ru.coursework.monitor.domain;

import jakarta.persistence.*;

@Entity
public class Measurement {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  @ManyToOne(optional = false)
  public Patient patient;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  public Metric metric;

  @Column(name = "reading_value", nullable = false)
  public double value;

  public Double heightCm;

  public Double bmi() {
    if (metric != Metric.WEIGHT || heightCm == null) return null;
    double meters = heightCm / 100;
    return Math.round(100 * value / (meters * meters)) / 100.0;
  }

  @Column(nullable = false)
  public java.time.Instant occurredAt;

  @Column(nullable = false)
  public java.time.Instant registeredAt;

  @Column(nullable = false)
  public String author;

  @Column(length = 500)
  public String note;
}
