package ru.coursework.monitor.config;

import java.time.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.coursework.monitor.domain.*;
import ru.coursework.monitor.repository.*;

/** Синтетические данные локального учебного стенда. Существующая база не перезаписывается. */
@Component
@ConditionalOnProperty(name = "app.demo-data", havingValue = "true")
public class DemoData implements CommandLineRunner {
  private final AccountRepository users;
  private final PatientRepository patients;
  private final MeasurementRepository measurements;
  private final ActivityRepository activities;
  private final MonitoringRuleRepository rules;
  private final AlertRepository alerts;
  private final PasswordEncoder encoder;

  public DemoData(
      AccountRepository u,
      PatientRepository p,
      MeasurementRepository m,
      ActivityRepository a,
      MonitoringRuleRepository r,
      AlertRepository al,
      PasswordEncoder e) {
    users = u;
    patients = p;
    measurements = m;
    activities = a;
    rules = r;
    alerts = al;
    encoder = e;
  }

  private Account user(String name, String role, String password) {
    Account a = new Account();
    a.username = name;
    a.role = role;
    a.passwordHash = encoder.encode(password);
    return users.save(a);
  }

  @Override
  @Transactional
  public void run(String... args) {
    if (users.count() != 0) return;
    user("admin", "ADMIN", "Admin2026!");
    Account doctor = user("doctor", "DOCTOR", "Doctor2026!");
    Account other = user("doctor2", "DOCTOR", "Doctor2026!");
    Account member = user("patient", "PATIENT", "Patient2026!");
    String[] names = {"Анна Соколова", "Михаил Орлов", "Елена Волкова", "Денис Смирнов"};
    for (int n = 0; n < 4; n++) {
      Patient p = new Patient();
      p.fullName = names[n];
      p.code = "PM-00" + (n + 1);
      p.birthDate = LocalDate.of(1985 + n * 3, 4 + n, 12);
      p.doctor = n == 3 ? other : doctor;
      p.account = n == 0 ? member : null;
      p.stepGoal = 6000 + n * 500;
      patients.save(p);
      MonitoringRule rule = MonitoringRule.defaults(Metric.PULSE);
      rule.patient = p;
      rules.save(rule);
      for (int d = 13; d >= 0; d--) {
        Measurement m = new Measurement();
        m.patient = p;
        m.metric = Metric.PULSE;
        m.value = d == 0 && n == 0 ? 112 : 68 + (d * 7 + n * 3) % 24;
        m.occurredAt =
            LocalDate.now()
                .minusDays(d)
                .atStartOfDay(ZoneId.of("Europe/Moscow"))
                .plusHours(1)
                .toInstant();
        if (m.occurredAt.isAfter(Instant.now())) m.occurredAt = Instant.now().minusSeconds(60);
        m.registeredAt = Instant.now();
        m.author = "doctor";
        m.note = "Учебное наблюдение";
        measurements.save(m);
        Activity a = new Activity();
        a.patient = p;
        a.day = LocalDate.now().minusDays(d);
        a.kind = "WALK";
        a.minutes = 35 + d * 2;
        a.steps = 3800 + (d * 713 + n * 571) % 4800;
        a.distanceKm = Math.round(a.steps * 0.0007 * 10) / 10.0;
        a.author = "patient";
        activities.save(a);
        if (m.value > rule.upperBound) {
          Alert alert = new Alert();
          alert.measurement = m;
          alert.lowerBound = rule.lowerBound;
          alert.upperBound = rule.upperBound;
          alerts.save(alert);
        }
      }
    }
  }
}
