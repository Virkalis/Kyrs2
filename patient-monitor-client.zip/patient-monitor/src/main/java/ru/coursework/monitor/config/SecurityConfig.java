package ru.coursework.monitor.config;

import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.*;
import ru.coursework.monitor.repository.AccountRepository;

/** Сессионная аутентификация, BCrypt и защита изменяющих запросов. */
@Configuration
@EnableMethodSecurity
public class SecurityConfig {
  @Bean
  PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  @Bean
  UserDetailsService userDetailsService(AccountRepository users) {
    return username ->
        users
            .findByUsername(username)
            .map(u -> User.withUsername(u.username).password(u.passwordHash).roles(u.role).build())
            .orElseThrow(() -> new UsernameNotFoundException("Пользователь не найден"));
  }

  @Bean
  SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http.authorizeHttpRequests(
        a ->
            a.requestMatchers(
                    "/",
                    "/index.html",
                    "/app.js",
                    "/style.css",
                        "/theme.js",
                    "/favicon.svg",
                    "/api/session/csrf",
                    "/api/session/login",
                    "/error")
                .permitAll()
                .anyRequest()
                .authenticated());
    http.csrf(
        c ->
            c.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
                .csrfTokenRequestHandler(new CsrfTokenRequestAttributeHandler()));
    http.formLogin(
        f ->
            f.loginProcessingUrl("/api/session/login")
                .successHandler(
                    (req, res, auth) -> {
                      res.setContentType("application/json;charset=UTF-8");
                      res.getWriter().write("{\"authenticated\":true}");
                    })
                .failureHandler(
                    (req, res, e) -> {
                      res.setStatus(401);
                      res.setContentType("application/problem+json;charset=UTF-8");
                      res.getWriter()
                          .write("{\"status\":401,\"detail\":\"Неверный логин или пароль\"}");
                    }));
    http.logout(
        l ->
            l.logoutUrl("/api/session/logout")
                .logoutSuccessHandler((req, res, auth) -> res.setStatus(204)));
    http.exceptionHandling(
        e ->
            e.authenticationEntryPoint(
                    (req, res, ex) -> {
                      res.setStatus(401);
                      res.setContentType("application/problem+json;charset=UTF-8");
                      res.getWriter()
                          .write("{\"status\":401,\"detail\":\"Необходим вход в систему\"}");
                    })
                .accessDeniedHandler(
                    (req, res, ex) -> {
                      res.setStatus(403);
                      res.setContentType("application/problem+json;charset=UTF-8");
                      res.getWriter()
                          .write(
                              "{\"status\":403,\"detail\":\"Недостаточно прав или недействителен"
                                  + " CSRF-токен\"}");
                    }));
    http.headers(h -> h.contentTypeOptions(c -> {}).frameOptions(f -> f.deny()));
    return http.build();
  }
}
