package ru.coursework.monitor.domain;

import jakarta.persistence.*;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = "measurement_id"))
public class Alert {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  @Version public long version;

  @OneToOne(optional = false)
  public Measurement measurement;

  public double lowerBound;
  public double upperBound;
  public Double criticalLowerBound;
  public Double criticalUpperBound;

  @Column(nullable = false)
  public String status = "NEW";

  public java.time.Instant reviewedAt;
  public String reviewer;

  @Column(length = 1000)
  public String comment;
}
