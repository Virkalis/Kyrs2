package ru.coursework.monitor.domain;

/** Технические пределы ввода; не медицинские нормативы. */
public enum Metric {
  PULSE("Пульс", "уд/мин", 20, 250),
  SYSTOLIC("Систолическое давление", "мм рт. ст.", 40, 300),
  DIASTOLIC("Диастолическое давление", "мм рт. ст.", 20, 200),
  WEIGHT("Масса тела", "кг", 1, 400),
  TEMPERATURE("Температура", "°C", 25, 45),
  SPO2("Сатурация", "%", 40, 100),
  BMI("ИМТ", "кг/м²", 0.1, 5000);
  public final String label, unit;
  public final double min, max;

  Metric(String label, String unit, double min, double max) {
    this.label = label;
    this.unit = unit;
    this.min = min;
    this.max = max;
  }

  public Metric assessmentMetric() {
    return this == WEIGHT ? BMI : this;
  }
}
