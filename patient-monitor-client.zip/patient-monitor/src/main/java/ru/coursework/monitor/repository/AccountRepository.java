package ru.coursework.monitor.repository;

import ru.coursework.monitor.domain.*;

public interface AccountRepository
    extends org.springframework.data.jpa.repository.JpaRepository<Account, Long> {
  java.util.Optional<Account> findByUsername(String username);

  java.util.List<Account> findByRole(String role);
}
