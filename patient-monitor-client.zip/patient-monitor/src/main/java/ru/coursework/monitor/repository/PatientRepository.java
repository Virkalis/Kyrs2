package ru.coursework.monitor.repository;

import ru.coursework.monitor.domain.*;

public interface PatientRepository
    extends org.springframework.data.jpa.repository.JpaRepository<Patient, Long> {
  @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
  @org.springframework.data.jpa.repository.Query("select p from Patient p where p.id=:id")
  java.util.Optional<Patient> lockById(
      @org.springframework.data.repository.query.Param("id") Long id);
}
