package ru.coursework.monitor.domain;

import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Table(uniqueConstraints = @UniqueConstraint(columnNames = {"patient_id", "metric"}))
public class MonitoringRule {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Long id;

  @ManyToOne(optional = false)
  public Patient patient;

  @Enumerated(EnumType.STRING)
  @JdbcTypeCode(SqlTypes.VARCHAR)
  @Column(nullable = false)
  public Metric metric;

  public double lowerBound;
  public double upperBound;
  public Double criticalLowerBound;
  public Double criticalUpperBound;

  /** Учебные границы для взрослых. Индивидуальное правило имеет приоритет. */
  public static MonitoringRule defaults(Metric metric) {
    return switch (metric) {
      case PULSE -> preset(metric, 55, 100, null, null);
      case SYSTOLIC -> preset(metric, 90, 120, 80.0, 180.0);
      case DIASTOLIC -> preset(metric, 60, 80, 45.0, 120.0);
      case TEMPERATURE -> preset(metric, 36.1, 38, 35.0, 39.1);
      case SPO2 -> preset(metric, 96, 100, 91.0, null);
      case BMI -> preset(metric, 18.5, 24.99, 16.0, 40.0);
      case WEIGHT -> throw new IllegalArgumentException("Для оценки массы используется ИМТ");
    };
  }

  private static MonitoringRule preset(
      Metric metric, double lower, double upper, Double criticalLower, Double criticalUpper) {
    MonitoringRule rule = new MonitoringRule();
    rule.metric = metric;
    rule.lowerBound = lower;
    rule.upperBound = upper;
    rule.criticalLowerBound = criticalLower;
    rule.criticalUpperBound = criticalUpper;
    return rule;
  }
}
